//
//  Game.swift
//  TicTacToeTests
//
//  Created by Lambda_School_Loaner_268 on 3/18/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation

struct Game {
    
  enum GameState {
        case active(GameBoard.Mark) // Active player
        case cat
        case won(GameBoard.Mark) // Winning player
    }

    private(set) var board: GameBoard = GameBoard()

    internal var activePlayer: GameBoard.Mark? = nil
    internal var gameIsOver: Bool = false
    internal var winningPlayer: GameBoard.Mark? = nil
    var gameState: GameState = .active(.x)
    
    mutating internal func restart() {
        gameState = .active(.x)
        self.board = GameBoard()
        self.activePlayer = .x
        gameIsOver = false
    }
    mutating internal func makeMark(at coordinate: Coordinate) {
        guard case let GameState.active(player) = self.gameState else {
            NSLog("Game is over")
            return
        }
        
        do {
            try board.place(mark: player, on: coordinate)
            if game(board: board, isWonBy: player) {
                gameState = .won(player)
                gameIsOver = true
            } else if board.isFull {
                gameState = .cat
                gameIsOver = true
            } else {
                let newPlayer = player == .x ? GameBoard.Mark.o : GameBoard.Mark.x
                gameState = .active(newPlayer)
            }
        } catch {
            NSLog("Illegal move")
        }
    }
    
    func game(board: GameBoard, isWonBy player: GameBoard.Mark) -> Bool {
        // Check verticals
        for x in 0..<3 {
            var numMarks = 0
            for y in 0..<3 {
                if board[(x, y)] == player {
                    numMarks += 1
                }
            }
            if numMarks == 3 {
                return true
            }
        }
        
        // Check horizontals
        for y in 0..<3 {
            var numMarks = 0
            for x in 0..<3 {
                if board[(x, y)] == player {
                    numMarks += 1
                }
            }
            if numMarks == 3 {
                return true
            }
        }
        
        // Check diagonals
        let ltr: [Coordinate] = [(0,0), (1, 1), (2,2)]
        var numMatches = 0
        for coord in ltr {
            if board[coord] == player {
                numMatches += 1
            }
        }
        if numMatches == 3 { return true }
        
        let rtl: [Coordinate] = [(2,0), (1, 1), (0,2)]
        numMatches = 0
        for coord in rtl {
            if board[coord] == player {
                numMatches += 1
            }
        }
        if numMatches == 3 { return true }
        
        return false
    }
        }
